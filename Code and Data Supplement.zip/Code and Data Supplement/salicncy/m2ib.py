from scripts.methods import vision_heatmap_iba,text_heatmap_iba
import numpy as np

def m2ib(
    model,
    text_ids,
    image_feat,
    beta=0.1,
    target_layer=9,
    noise_mode=None,
    sigma_fixed=0.1,
    sigma_min=0.05,
    sigma_max=1.0,
):
    saliency_v = []
    saliency_t = []
    for idx in range(image_feat.shape[0]):
        t_id = text_ids[idx]
        i_feat = image_feat[idx:idx+1]
        vmap = vision_heatmap_iba(t_id, i_feat, model, target_layer, beta, 1,
                                 noise_mode=noise_mode, sigma_fixed=sigma_fixed,
                                 sigma_min=sigma_min, sigma_max=sigma_max)
        tmap = text_heatmap_iba(t_id, i_feat, model, target_layer, beta, 1,
                                noise_mode=noise_mode, sigma_fixed=sigma_fixed,
                                sigma_min=sigma_min, sigma_max=sigma_max)
        saliency_v.append(vmap)
        saliency_t.append(tmap)
    return np.stack(saliency_v, axis=0), saliency_t
