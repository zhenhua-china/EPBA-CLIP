import os

import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Rectangle


OUT_DIR = "figures"
OUT_BASE = "model_internal_structure"


COLORS = {
    "visual": "#CFEFEA",
    "visual_edge": "#00A99D",
    "text": "#DFF3D8",
    "text_edge": "#63B35D",
    "part": "#E8F2FF",
    "part_edge": "#4D8FDB",
    "ot": "#F4E9FF",
    "ot_edge": "#8D63D9",
    "head": "#E8FAFF",
    "head_edge": "#22A6C8",
    "orange": "#FFF0D9",
    "orange_edge": "#E59A35",
    "gray": "#F3F4F6",
    "gray_edge": "#9CA3AF",
    "loss": "#FFF8CC",
    "loss_edge": "#D6A700",
}


def add_box(ax, xy, wh, text, fc, ec, fontsize=8.5, lw=1.25, radius=0.08, dashed=False):
    x, y = xy
    w, h = wh
    style = f"round,pad=0.02,rounding_size={radius}"
    patch = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle=style,
        linewidth=lw,
        edgecolor=ec,
        facecolor=fc,
        linestyle="--" if dashed else "-",
        zorder=2,
    )
    ax.add_patch(patch)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fontsize, zorder=3)
    return patch


def add_panel(ax, xy, wh, title, color, edge):
    x, y = xy
    w, h = wh
    patch = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle="round,pad=0.015,rounding_size=0.25",
        linewidth=1.5,
        edgecolor=edge,
        facecolor=color,
        linestyle="--",
        alpha=0.35,
        zorder=0,
    )
    ax.add_patch(patch)
    ax.text(x + w / 2, y + h - 1.8, title, ha="center", va="top", fontsize=11, fontweight="bold", color=edge)
    return patch


def arrow(ax, start, end, color="#374151", lw=1.4, style="-", rad=0.0, mutation=10):
    arr = FancyArrowPatch(
        start,
        end,
        arrowstyle="-|>",
        mutation_scale=mutation,
        linewidth=lw,
        linestyle=style,
        color=color,
        shrinkA=2,
        shrinkB=2,
        connectionstyle=f"arc3,rad={rad}",
        zorder=4,
    )
    ax.add_patch(arr)
    return arr


def draw_patch_grid(ax, x, y, cell=1.05, rows=5, cols=5, active=None):
    active = active or set()
    for r in range(rows):
        for c in range(cols):
            val = (r + c) / (rows + cols)
            fc = "#D8F3DC" if (r, c) not in active else "#70D6A3"
            if (r, c) in active:
                fc = ["#C3F0CA", "#83D992", "#42B883"][(r + c) % 3]
            rect = Rectangle((x + c * cell, y + (rows - 1 - r) * cell), cell * 0.86, cell * 0.86,
                             facecolor=fc, edgecolor="#6B7280", linewidth=0.35, zorder=3)
            ax.add_patch(rect)
    ax.text(x + cols * cell / 2 - 0.25, y - 1.1, "patch tokens F", ha="center", va="top", fontsize=7.5)


def draw_matrix(ax, x, y, rows, cols, w=0.9, h=0.9, colors=None, label=None):
    palette = colors or ["#F7FBFF", "#D0E1F2", "#8FBBD9", "#F8D7A8", "#C7E9C0"]
    for r in range(rows):
        for c in range(cols):
            fc = palette[(r * 2 + c * 3) % len(palette)]
            ax.add_patch(Rectangle((x + c * w, y + (rows - 1 - r) * h), w * 0.92, h * 0.92,
                                   facecolor=fc, edgecolor="white", linewidth=0.45, zorder=3))
    if label:
        ax.text(x + cols * w / 2, y - 1.0, label, ha="center", va="top", fontsize=7.5)


def draw_bars(ax, x, y, values, label=None):
    for i, value in enumerate(values):
        ax.add_patch(Rectangle((x + i * 1.05, y), 0.72, value, facecolor="#9AD7E5",
                               edgecolor="#4B9FB1", linewidth=0.6, zorder=3))
    if label:
        ax.text(x + len(values) * 0.53, y - 1.0, label, ha="center", va="top", fontsize=7.5)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    fig, ax = plt.subplots(figsize=(16, 8.2), dpi=220)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 60)
    ax.axis("off")

    add_panel(ax, (1.5, 13), (23, 43), "A. Token-Coordinated\nVisual-Text Encoding", COLORS["visual"], COLORS["visual_edge"])
    add_panel(ax, (26, 13), (25, 43), "B. Structured\nPart Discovery", COLORS["part"], COLORS["part_edge"])
    add_panel(ax, (52.5, 13), (23, 43), "C. Part-Grounded\nVisual-Text OT Alignment", COLORS["ot"], COLORS["ot_edge"])
    add_panel(ax, (77, 13), (21.5, 43), "D. Rule-Based Interactive\nClassification Head", COLORS["head"], COLORS["head_edge"])

    # A. Encoding.
    add_box(ax, (3.2, 43.5), (6.2, 7), "Image\nx", "#FFFFFF", COLORS["visual_edge"], fontsize=9)
    draw_patch_grid(ax, 4.0, 35.5, active={(1, 1), (1, 2), (2, 2), (3, 3)})
    add_box(ax, (11.2, 35.2), (5.5, 9.5), "ViT patch\nembedding", COLORS["gray"], COLORS["gray_edge"], fontsize=8.5)
    add_box(ax, (18.0, 35.2), (4.9, 9.5), "TCPA\nblocks", "#E5F8F5", COLORS["visual_edge"], fontsize=9)
    arrow(ax, (9.4, 47), (11.2, 40), COLORS["visual_edge"])
    arrow(ax, (16.7, 40), (18.0, 40), COLORS["visual_edge"])

    add_box(ax, (3.0, 23.5), (8.0, 7.0), "Concept\nphrases", "#FFFFFF", COLORS["text_edge"], fontsize=8.5)
    add_box(ax, (12.0, 23.5), (6.1, 7.0), "Frozen text\nencoder", COLORS["text"], COLORS["text_edge"], fontsize=8.5)
    add_box(ax, (19.0, 23.5), (4.3, 7.0), "Textual\nadapter", "#EAF8E7", COLORS["text_edge"], fontsize=8.5)
    arrow(ax, (11, 27), (12, 27), COLORS["text_edge"])
    arrow(ax, (18.1, 27), (19, 27), COLORS["text_edge"])

    add_box(ax, (8.3, 15.2), (13.6, 7.0), "TCPA internal: F^l, E\n-> coord. gate g_l\n-> residual Delta F_l", "#FFFFFF", COLORS["visual_edge"], fontsize=7.8)
    arrow(ax, (20.5, 35.2), (16.3, 22.2), COLORS["visual_edge"], style="--", rad=0.12)
    arrow(ax, (21.2, 23.5), (16.8, 22.2), COLORS["text_edge"], style="--", rad=-0.12)
    add_box(ax, (22.8, 39.0), (1.4, 6.0), "F_hat", "#D0F2EA", COLORS["visual_edge"], fontsize=7.2)
    arrow(ax, (22.9, 40), (26.3, 40), COLORS["visual_edge"], mutation=12)

    # B. Part discovery.
    add_box(ax, (27.4, 39.0), (6.3, 6.8), "Corrected\npatch tokens\nF_hat", "#FFFFFF", COLORS["part_edge"], fontsize=8.2)
    add_box(ax, (27.6, 27.3), (6.0, 6.5), "Learnable part\nprototypes\nq_1...q_R", COLORS["orange"], COLORS["orange_edge"], fontsize=8.0)
    add_box(ax, (35.5, 35.6), (5.8, 7.6), "Soft assignment\nA[i,r]\nsoftmax(f_i q_r)", "#FFFFFF", COLORS["part_edge"], fontsize=7.5)
    add_box(ax, (35.5, 25.8), (5.8, 7.0), "Foreground gate\nm[i,r]\nsigma(f_i u)", "#FFFFFF", COLORS["part_edge"], fontsize=7.5)
    draw_matrix(ax, 43.0, 34.3, 4, 4, w=0.9, h=0.9, label="part maps M_r")
    add_box(ax, (43.0, 25.4), (5.6, 6.6), "Weighted pooling\nz_r = sum m f\n/ sum m", COLORS["gray"], COLORS["gray_edge"], fontsize=7.5)
    add_box(ax, (43.8, 17.2), (4.0, 4.9), "Part\nembeddings\nz_1...z_R", "#FFFFFF", COLORS["part_edge"], fontsize=7.8)
    arrow(ax, (33.7, 42), (35.5, 39.4), COLORS["part_edge"])
    arrow(ax, (33.6, 30.5), (35.5, 29.3), COLORS["orange_edge"])
    arrow(ax, (41.3, 39.4), (43.0, 37.0), COLORS["part_edge"])
    arrow(ax, (41.3, 29.3), (43.0, 36.0), COLORS["orange_edge"], rad=0.1)
    arrow(ax, (45.1, 34.0), (45.8, 32.0), COLORS["part_edge"])
    arrow(ax, (45.8, 25.4), (45.8, 22.1), COLORS["part_edge"])
    arrow(ax, (47.8, 19.6), (52.7, 39.0), COLORS["part_edge"], mutation=12)

    # C. OT alignment.
    add_box(ax, (53.8, 39.0), (5.5, 6.8), "Visual parts\nz_r", "#FFFFFF", COLORS["ot_edge"], fontsize=8.2)
    add_box(ax, (53.8, 24.4), (5.5, 6.8), "Concept\nfeatures\ne_n", "#FFFFFF", COLORS["text_edge"], fontsize=8.2)
    add_box(ax, (61.0, 34.5), (5.2, 7.2), "Cost matrix\nC[r,n]\n1-cos(z,e)", COLORS["orange"], COLORS["orange_edge"], fontsize=7.4)
    draw_matrix(ax, 67.7, 34.7, 5, 5, w=0.78, h=0.78, label="C")
    add_box(ax, (61.0, 24.8), (5.2, 6.4), "Sinkhorn\nOT solver", "#FFFFFF", COLORS["ot_edge"], fontsize=8.0)
    draw_matrix(ax, 67.7, 24.5, 5, 5, w=0.78, h=0.78, label="Pi")
    add_box(ax, (69.3, 16.8), (4.7, 5.6), "Concept\nactivation\nvector a", "#FFFFFF", COLORS["ot_edge"], fontsize=7.8)
    draw_bars(ax, 68.6, 43.6, [1.2, 2.8, 0.8, 3.4, 1.7], label="activation")
    arrow(ax, (59.3, 42), (61.0, 38.5), COLORS["ot_edge"])
    arrow(ax, (59.3, 27.8), (61.0, 37.8), COLORS["text_edge"], rad=0.08)
    arrow(ax, (66.2, 38.0), (67.7, 37.0), COLORS["orange_edge"])
    arrow(ax, (63.6, 34.5), (63.6, 31.2), COLORS["ot_edge"])
    arrow(ax, (66.2, 28.0), (67.7, 27.0), COLORS["ot_edge"])
    arrow(ax, (69.8, 24.5), (71.7, 22.4), COLORS["ot_edge"])
    arrow(ax, (72.8, 42.8), (72.0, 22.4), COLORS["ot_edge"], rad=-0.06)
    arrow(ax, (74.0, 19.8), (77.0, 39.6), COLORS["ot_edge"], mutation=12)

    # D. Classification head.
    add_box(ax, (78.4, 38.5), (6.5, 7.1), "Sparse concept\ngating\nTop-k / mask", "#FFFFFF", COLORS["head_edge"], fontsize=7.8)
    add_box(ax, (86.0, 42.8), (5.2, 5.8), "Additive\nmain effects\nw^T a", COLORS["gray"], COLORS["gray_edge"], fontsize=7.4)
    add_box(ax, (86.0, 33.2), (5.2, 5.8), "Low-rank\ninteractions\nU(a) x V(a)", COLORS["gray"], COLORS["gray_edge"], fontsize=7.2)
    add_box(ax, (92.4, 37.8), (4.2, 5.3), "Logits\nsum", "#FFFFFF", COLORS["head_edge"], fontsize=8.0)
    add_box(ax, (84.0, 19.0), (5.9, 5.2), "Active concepts\nand scores", "#FFFFFF", COLORS["head_edge"], fontsize=7.6)
    add_box(ax, (91.0, 19.0), (5.8, 5.2), "Class label\n+ rationale", COLORS["orange"], COLORS["orange_edge"], fontsize=7.8)
    arrow(ax, (84.9, 42.0), (86.0, 45.5), COLORS["head_edge"])
    arrow(ax, (84.9, 40.0), (86.0, 36.1), COLORS["head_edge"])
    arrow(ax, (91.2, 45.5), (92.4, 40.9), COLORS["gray_edge"])
    arrow(ax, (91.2, 36.1), (92.4, 40.0), COLORS["gray_edge"])
    arrow(ax, (94.5, 37.8), (94.1, 24.2), COLORS["head_edge"])
    arrow(ax, (89.9, 21.6), (91.0, 21.6), COLORS["head_edge"])
    arrow(ax, (81.6, 38.5), (86.8, 24.2), COLORS["head_edge"], style="--", rad=-0.12)

    # Loss strip.
    add_box(
        ax,
        (6.0, 4.2),
        (88.0, 5.8),
        "Training objectives:  L_cls  +  L_part (smoothness, diversity, existence)  +  L_OT  +  L_sparse / interaction regularization",
        COLORS["loss"],
        COLORS["loss_edge"],
        fontsize=9.2,
        radius=0.16,
    )
    for x in [16, 38, 64, 88]:
        arrow(ax, (x, 10.0), (x, 14.0), COLORS["loss_edge"], style="--", mutation=8)

    ax.text(
        50,
        58.3,
        "Internal Architecture and Information Flow of the Proposed Concept Bottleneck Model",
        ha="center",
        va="center",
        fontsize=14,
        fontweight="bold",
    )
    ax.text(
        50,
        1.5,
        "Solid arrows: forward inference flow. Dashed arrows: coordination or training constraints.",
        ha="center",
        va="center",
        fontsize=8.5,
        color="#4B5563",
    )

    svg_path = os.path.join(OUT_DIR, f"{OUT_BASE}.svg")
    png_path = os.path.join(OUT_DIR, f"{OUT_BASE}.png")
    pdf_path = os.path.join(OUT_DIR, f"{OUT_BASE}.pdf")
    fig.savefig(svg_path, bbox_inches="tight", pad_inches=0.08)
    fig.savefig(pdf_path, bbox_inches="tight", pad_inches=0.08)
    fig.savefig(png_path, bbox_inches="tight", pad_inches=0.08, dpi=300)
    print(svg_path)
    print(pdf_path)
    print(png_path)


if __name__ == "__main__":
    main()
