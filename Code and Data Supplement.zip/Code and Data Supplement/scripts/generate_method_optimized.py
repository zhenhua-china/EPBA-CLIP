import os

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle


OUT_DIR = "figures"
OUT_BASE = "Method_optimized"


COL = {
    "teal": "#19A99D",
    "teal_light": "#EAF9F7",
    "purple": "#7C5BD6",
    "purple_light": "#F5F0FF",
    "cyan": "#1AA9C7",
    "cyan_light": "#ECFAFE",
    "green": "#5CB85C",
    "green_light": "#EEF9EC",
    "orange": "#E99A2D",
    "orange_light": "#FFF2DD",
    "blue": "#3F8FD9",
    "blue_light": "#EEF6FF",
    "gray": "#6B7280",
    "gray_light": "#F3F4F6",
    "dark": "#111827",
}


def box(ax, x, y, w, h, text, fc="white", ec="#333333", fs=9, lw=1.2, dash=False, r=0.16, weight="normal"):
    p = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle=f"round,pad=0.018,rounding_size={r}",
        linewidth=lw,
        edgecolor=ec,
        facecolor=fc,
        linestyle="--" if dash else "-",
        zorder=2,
    )
    ax.add_patch(p)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, fontweight=weight, zorder=3)
    return p


def panel(ax, x, y, w, h, title, ec, fc):
    p = FancyBboxPatch(
        (x, y),
        w,
        h,
        boxstyle="round,pad=0.015,rounding_size=0.22",
        linewidth=1.6,
        edgecolor=ec,
        facecolor=fc,
        linestyle="--",
        alpha=0.72,
        zorder=0,
    )
    ax.add_patch(p)
    ax.text(x + w / 2, y + h - 1.5, title, ha="center", va="top", fontsize=15, fontweight="bold", color=ec)
    return p


def arrow(ax, a, b, color="#333333", lw=1.5, dash=False, rad=0.0, ms=11):
    arr = FancyArrowPatch(
        a,
        b,
        arrowstyle="-|>",
        mutation_scale=ms,
        color=color,
        linewidth=lw,
        linestyle="--" if dash else "-",
        connectionstyle=f"arc3,rad={rad}",
        shrinkA=2,
        shrinkB=2,
        zorder=5,
    )
    ax.add_patch(arr)
    return arr


def grid(ax, x, y, rows=4, cols=4, cell=0.62, hot=None, label=None, cmap="green"):
    hot = hot or set()
    palettes = {
        "green": ["#EFFAF2", "#C6EBCF", "#85D496", "#3FB76E"],
        "blue": ["#F1F7FF", "#CFE2FA", "#8AB7E5", "#3F8FD9"],
        "heat": ["#EEF2FF", "#BBD7F0", "#F6D491", "#E58C52"],
    }
    pal = palettes[cmap]
    for r in range(rows):
        for c in range(cols):
            v = (r * 2 + c * 3) % len(pal)
            fc = pal[v] if (r, c) in hot or cmap != "green" else "#EEF7F1"
            ax.add_patch(Rectangle((x + c * cell, y + (rows - 1 - r) * cell), cell * 0.86, cell * 0.86,
                                   facecolor=fc, edgecolor="#8B9AA8", linewidth=0.35, zorder=3))
    if label:
        ax.text(x + cols * cell / 2, y - 0.62, label, ha="center", va="top", fontsize=7)


def matrix(ax, x, y, rows=5, cols=5, cell=0.55, label=None):
    colors = ["#F8FAFC", "#C9DAEE", "#EBD9B7", "#B8E0C8", "#C7B7EA", "#F3B783"]
    for r in range(rows):
        for c in range(cols):
            ax.add_patch(Rectangle((x + c * cell, y + (rows - 1 - r) * cell), cell * 0.92, cell * 0.92,
                                   facecolor=colors[(r * 2 + c * 3) % len(colors)],
                                   edgecolor="white", linewidth=0.35, zorder=3))
    if label:
        ax.text(x + cols * cell / 2, y - 0.55, label, ha="center", va="top", fontsize=7.2)


def bars(ax, x, y, values, color="#9AD7E5", ec="#4B9FB1", label=None):
    for i, v in enumerate(values):
        ax.add_patch(Rectangle((x + i * 0.62, y), 0.42, v, facecolor=color, edgecolor=ec, linewidth=0.55, zorder=3))
    if label:
        ax.text(x + len(values) * 0.31, y - 0.55, label, ha="center", va="top", fontsize=7.2)


def small_tokens(ax, x, y, n=6, color="#A8DADC", ec="#64748B", label=None):
    for i in range(n):
        ax.add_patch(Rectangle((x + i * 0.55, y), 0.38, 0.72, facecolor=color, edgecolor=ec, linewidth=0.4, zorder=3))
    if label:
        ax.text(x + n * 0.28, y - 0.45, label, ha="center", va="top", fontsize=7)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    fig, ax = plt.subplots(figsize=(19.2, 6.2), dpi=240)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 32)
    ax.axis("off")

    panel(ax, 0.6, 1.0, 28.0, 30.2, "Token-Coordinated Visual-Text Encoding", COL["teal"], COL["teal_light"])
    panel(ax, 29.2, 1.0, 43.2, 30.2, "Part-Grounded Visual-Text OT Alignment", COL["purple"], COL["purple_light"])
    panel(ax, 73.0, 1.0, 26.4, 30.2, "Rule-Based Interactive Classification Head", COL["cyan"], COL["cyan_light"])

    
    box(ax, 1.4, 16.4, 26.4, 13.3, "", fc="white", ec="#B8E3DD", lw=0.9, r=0.12)
    ax.text(22.8, 28.7, "Visual Branch", ha="center", va="center", fontsize=10, fontweight="bold")
    box(ax, 1.3, 12.8, 26.5, 2.0, "Text Branch", fc="#DDF4EF", ec="#B8E3DD", fs=10, weight="bold")

    box(ax, 2.0, 20.1, 6.4, 6.4, "Image\npatch grid", fc="white", ec=COL["teal"], fs=9)
    grid(ax, 2.65, 21.15, rows=4, cols=4, hot={(1, 1), (1, 2), (2, 2)}, label="patch tokens")
    box(ax, 10.0, 20.1, 6.1, 6.4, "Frozen ViT\nTransformer\nblocks", fc=COL["gray_light"], ec="#9CA3AF", fs=8.7)
    box(ax, 10.7, 24.9, 4.7, 1.0, "Block 12", fc="white", ec="#D1D5DB", fs=7.2)
    box(ax, 10.7, 22.8, 4.7, 1.0, "...", fc="white", ec="#D1D5DB", fs=8.0)
    box(ax, 10.7, 20.7, 4.7, 1.0, "Block 1", fc="white", ec="#D1D5DB", fs=7.2)

    box(ax, 17.3, 18.5, 8.8, 8.8, "TCPA Injection\ninside selected blocks", fc="#E4F8F5", ec=COL["teal"], fs=8.8, weight="bold")
    small_tokens(ax, 18.1, 25.5, n=6, color="#CFEFEA", label="tokens")
    box(ax, 18.0, 23.2, 3.2, 1.4, "img prompt\npool", fc="white", ec=COL["teal"], fs=6.8)
    box(ax, 22.1, 23.2, 3.2, 1.4, "CLS prompt\npool", fc="white", ec=COL["teal"], fs=6.8)
    box(ax, 18.0, 20.8, 7.3, 1.55, "indicator similarity -> Soft Top-K gate", fc="white", ec=COL["teal"], fs=7.0)
    box(ax, 18.0, 18.9, 7.3, 1.35, "delta prompt + residual MLP", fc="white", ec=COL["teal"], fs=7.0)
    arrow(ax, (8.4, 23.3), (10.0, 23.3), COL["teal"], ms=12)
    arrow(ax, (16.1, 23.3), (17.3, 23.3), COL["teal"], ms=12)
    arrow(ax, (21.6, 18.5), (26.0, 16.5), COL["teal"], rad=-0.15)
    box(ax, 23.8, 15.1, 2.7, 1.7, "F_hat", fc="#DDF4EF", ec=COL["teal"], fs=8)

    box(ax, 2.0, 3.0, 7.5, 8.6, "Concept phrases\n\nall-purpose bill\nblack tail\nsolid back\n...\nwhite breast", fc="#F8FEFC", ec=COL["green"], fs=7.3)
    box(ax, 11.0, 5.5, 5.8, 3.4, "CLIP text\nencoder\n(frozen)", fc=COL["green_light"], ec=COL["green"], fs=8.2)
    box(ax, 18.0, 5.5, 5.0, 3.4, "Text\nadapter", fc="#F4FFF2", ec=COL["green"], fs=8.2)
    small_tokens(ax, 23.9, 6.7, n=5, color="#D6EACF", ec=COL["green"], label="E")
    arrow(ax, (9.5, 7.3), (11.0, 7.3), COL["green"])
    arrow(ax, (16.8, 7.3), (18.0, 7.3), COL["green"])
    arrow(ax, (23.0, 7.3), (29.2, 8.2), COL["green"], ms=13)
    arrow(ax, (26.5, 15.9), (29.2, 19.0), COL["teal"], ms=13)

    
    box(ax, 30.4, 16.9, 6.1, 5.2, "Structured\nPart Discovery", fc=COL["green_light"], ec=COL["green"], fs=8.7, weight="bold", dash=True)
    box(ax, 37.0, 24.4, 7.4, 4.6, "Prototype assignment\nq_k · f_i -> softmax\nA[i,k]", fc="white", ec=COL["blue"], fs=7.4)
    box(ax, 37.0, 18.6, 7.4, 4.1, "Foreground gate\nsigmoid(f_i · u)\nM = A x s", fc="white", ec=COL["blue"], fs=7.4)
    matrix(ax, 45.7, 22.5, rows=3, cols=5, cell=0.48, label="part maps")
    box(ax, 49.8, 20.0, 5.6, 5.2, "Weighted pooling\nz_k = sum M f\n/ sum M", fc=COL["gray_light"], ec="#9CA3AF", fs=7.2)
    box(ax, 49.0, 14.6, 6.8, 2.5, "Part-level visual evidence z_1...z_K", fc="#F8FBFF", ec=COL["blue"], fs=7.5)
    arrow(ax, (36.5, 19.5), (37.0, 26.0), COL["blue"])
    arrow(ax, (36.5, 18.8), (37.0, 20.6), COL["blue"])
    arrow(ax, (44.4, 26.3), (45.7, 24.4), COL["blue"])
    arrow(ax, (44.4, 20.6), (45.7, 23.8), COL["blue"])
    arrow(ax, (48.5, 22.8), (49.8, 22.5), COL["blue"])
    arrow(ax, (52.6, 20.0), (52.6, 17.1), COL["blue"])

    box(ax, 31.4, 4.6, 11.0, 8.0, "Concept Feature\nCLIP text features E\n+ text adapter\n+ optional prior b", fc="#F8FEFC", ec="#8EC5FF", fs=8.3, dash=True)
    small_tokens(ax, 34.0, 10.4, n=6, color="#DDE9FA", ec="#8EC5FF", label="concept vectors")
    small_tokens(ax, 34.0, 8.2, n=6, color="#EBDCCA", ec="#8EC5FF")
    small_tokens(ax, 34.0, 6.0, n=6, color="#DDE9FA", ec="#8EC5FF")

    box(ax, 56.8, 16.0, 9.2, 13.0, "Optimal Transport Alignment", fc=COL["orange_light"], ec=COL["orange"], fs=9.0, weight="bold", dash=True)
    matrix(ax, 59.2, 24.1, rows=5, cols=5, cell=0.48, label="Cost C=1-cos(z,e)")
    box(ax, 59.0, 19.2, 4.8, 2.2, "K=exp(-C/eps)", fc="white", ec=COL["orange"], fs=7.2)
    box(ax, 58.6, 16.2, 5.7, 2.2, "Sinkhorn\nu,K,v -> Pi", fc="white", ec=COL["orange"], fs=7.2)
    matrix(ax, 59.2, 11.3, rows=5, cols=5, cell=0.48, label="Transport Plan Pi")
    arrow(ax, (55.4, 16.0), (59.0, 24.5), COL["purple"], ms=13)
    arrow(ax, (42.4, 8.3), (58.6, 24.5), COL["green"], ms=13, rad=0.08)
    arrow(ax, (61.4, 23.7), (61.4, 21.4), COL["purple"])
    arrow(ax, (61.4, 19.2), (61.4, 18.4), COL["purple"])
    arrow(ax, (61.4, 16.2), (61.4, 14.0), COL["purple"])

    box(ax, 66.8, 13.5, 4.1, 12.2, "Concept\nActivation\nVector", fc="#FFF9EB", ec="#DBC37D", fs=8.2)
    small_tokens(ax, 67.3, 21.8, n=5, color="#F4E8C1", ec="#C7AB55")
    arrow(ax, (68.2, 21.3), (68.2, 18.8), COL["purple"])
    small_tokens(ax, 67.3, 17.6, n=5, color="#D9EDF0", ec="#9BB8C0")
    ax.text(68.9, 15.6, "top-k evidence\nPi x exp(-C)\n+ calibration", ha="center", va="center", fontsize=6.8)
    arrow(ax, (63.8, 12.9), (66.8, 16.5), COL["purple"], ms=13)
    arrow(ax, (70.9, 19.5), (73.0, 21.0), COL["purple"], ms=14)

    box(ax, 78.0, 24.6, 14.0, 4.2, "Sparse Concept Gating", fc="white", ec="#7DD3E8", fs=10.5, weight="bold", dash=True)
    bars(ax, 79.8, 25.7, [2.1, 1.0, 0.45, 1.45, 2.6, 0.8, 0.55, 0.38], color="#E3D2F0", ec="#9D74C7", label="gate=sigmoid(logits), sparse mask")
    arrow(ax, (85.0, 24.6), (85.0, 22.8), COL["cyan"])

    box(ax, 77.6, 17.1, 7.7, 4.8, "Additive Main-Effect\nNAM curves\nh_i=ReLU(a_i w1+b1)\ncontrib_i=h_i w2", fc="white", ec="#7DD3E8", fs=7.2, dash=True)
    box(ax, 87.0, 17.1, 8.0, 4.8, "Low-rank Interaction\nz1=a_g V1, z2=a_g V2\n(z1*z2) Wi", fc="white", ec="#7DD3E8", fs=7.2, dash=True)
    arrow(ax, (82.0, 24.6), (81.4, 21.9), COL["cyan"])
    arrow(ax, (88.0, 24.6), (91.0, 21.9), COL["cyan"])
    ax.text(86.0, 15.2, "+", ha="center", va="center", fontsize=20, color=COL["cyan"],
            bbox=dict(boxstyle="circle,pad=0.08", fc="#E8FAFF", ec=COL["cyan"], lw=1.2))
    arrow(ax, (81.4, 17.1), (85.2, 15.2), COL["cyan"])
    arrow(ax, (91.0, 17.1), (86.8, 15.2), COL["cyan"])
    arrow(ax, (86.0, 14.2), (86.0, 11.9), COL["cyan"], ms=16)
    box(ax, 77.6, 5.0, 18.8, 6.7, "", fc="#F7FEFF", ec="#7DD3E8", dash=True)
    box(ax, 78.8, 7.0, 6.2, 3.2, "Predicted\nclass", fc="white", ec="#7DD3E8", fs=9.2, weight="bold", dash=True)
    box(ax, 87.2, 7.0, 6.8, 3.2, "Concept\nrationale", fc="#DDF2F8", ec="#7DD3E8", fs=9.0)
    small_tokens(ax, 90.5, 5.9, n=5, color="#89D9E8", ec="#38A9BE", label="class label")
    arrow(ax, (86.0, 11.7), (82.0, 10.2), COL["cyan"])
    arrow(ax, (86.0, 11.7), (90.6, 10.2), COL["cyan"])

    
    box(ax, 31.4, 1.9, 38.4, 2.0,
        "Auxiliary constraints: L_orth for disentanglement  +  L_part(TV, distinct, presence)  +  gate L1 / interaction L2",
        fc="#FFF8D6", ec="#D6A700", fs=7.4, r=0.08)
    arrow(ax, (40.5, 3.9), (40.5, 16.9), "#C9A000", dash=True, ms=8)
    arrow(ax, (57.0, 3.9), (57.0, 11.3), "#C9A000", dash=True, ms=8)
    arrow(ax, (88.0, 3.9), (88.0, 7.0), "#C9A000", dash=True, ms=8)

    ax.text(50, 0.35, "Solid arrows: forward information flow. Dashed boxes/arrows: internal selection or regularization.",
            ha="center", va="center", fontsize=7.8, color=COL["gray"])

    svg = os.path.join(OUT_DIR, OUT_BASE + ".svg")
    pdf = os.path.join(OUT_DIR, OUT_BASE + ".pdf")
    png = os.path.join(OUT_DIR, OUT_BASE + ".png")
    fig.savefig(svg, bbox_inches="tight", pad_inches=0.05)
    fig.savefig(pdf, bbox_inches="tight", pad_inches=0.05)
    fig.savefig(png, bbox_inches="tight", pad_inches=0.05, dpi=320)
    print(svg)
    print(pdf)
    print(png)


if __name__ == "__main__":
    main()
