

from scripts.iba import IBAInterpreter, Estimator
from AdaptiveNoiseGenerator import AdaptiveNoiseGenerator
import numpy as np
import clip
import copy
import torch 
from transformers import CLIPProcessor, CLIPModel, CLIPTokenizerFast


def extract_feature_map(model, layer_idx, x):
    with torch.no_grad():
        states = model(x, output_hidden_states=True) 
        feature = states['hidden_states'][layer_idx+1] # +1 because the first output is embedding 
        return feature


def extract_bert_layer(model, layer_idx):
    desired_layer = ''
    for _, submodule in model.named_children():
        for n, s in submodule.named_children():
            if n == 'layers' or n == 'resblocks':
                for n2, s2 in s.named_children():
                    if n2 == str(layer_idx):
                        desired_layer = s2
                        return desired_layer


def get_compression_estimator(var, layer, features):
    estimator = Estimator(layer)
    estimator.M = torch.zeros_like(features)
    estimator.S = var*np.ones(features.shape)
    estimator.N = 1
    estimator.layer = layer
    return estimator

def _build_noise_generator(features, noise_mode, sigma_fixed, sigma_min, sigma_max):
    if noise_mode is None:
        return None
    return AdaptiveNoiseGenerator(
        seq_len=features.shape[1],
        noise_mode=noise_mode,
        sigma_fixed=sigma_fixed,
        sigma_min=sigma_min,
        sigma_max=sigma_max,
        device=features.device,
    )

def text_heatmap_iba(text_t, image_t, model, layer_idx, beta, var, lr=1, train_steps=10, progbar=True,
                     noise_mode=None, sigma_fixed=1.0, sigma_min=0.05, sigma_max=1.0):
    features = extract_feature_map(model.text_model, layer_idx, text_t)
    layer = extract_bert_layer(model.text_model, layer_idx)
    compression_estimator = get_compression_estimator(var, layer, features)
    noise_generator = _build_noise_generator(features, noise_mode, sigma_fixed, sigma_min, sigma_max)
    reader = IBAInterpreter(model, compression_estimator, beta=beta, lr=lr, steps=train_steps, progbar=progbar,
                            noise_generator=noise_generator)
    return reader.text_heatmap(text_t, image_t)



def vision_heatmap_iba(text_t, image_t, model, layer_idx, beta, var, lr=1, train_steps=10, progbar=True,
                       noise_mode=None, sigma_fixed=1.0, sigma_min=0.05, sigma_max=1.0):
    features = extract_feature_map(model.vision_model, layer_idx, image_t)
    layer = extract_bert_layer(model.vision_model, layer_idx)
    compression_estimator = get_compression_estimator(var, layer, features)
    noise_generator = _build_noise_generator(features, noise_mode, sigma_fixed, sigma_min, sigma_max)
    reader = IBAInterpreter(model, compression_estimator, beta=beta, lr=lr, steps=train_steps, progbar=progbar,
                            noise_generator=noise_generator)
    return reader.vision_heatmap(text_t, image_t)
